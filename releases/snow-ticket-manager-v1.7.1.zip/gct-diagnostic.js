// gct-diagnostic.js — Run this in the GCT DevTools Console (F12) on any GCT page
// Tests: (1) REST API availability, (2) JS API WriteRecord deep debugging

(async function () {
  var results = {};

  // === TEST 1: REST API availability ===
  console.log("=== TEST 1: Siebel REST API ===");

  var restPaths = [
    "/Siebel/v1.0/data/describe",
    "/siebel/v1.0/data/describe",
    "/Siebel/v1.0/data/Action/Action/describe",
    "/Siebel/v1.0/data/Service Request/Service Request/describe"
  ];

  for (var i = 0; i < restPaths.length; i++) {
    try {
      var resp = await fetch(restPaths[i], {
        method: "GET",
        headers: { "Accept": "application/json" },
        credentials: "include"
      });
      console.log(restPaths[i] + " → " + resp.status + " " + resp.statusText);
      if (resp.ok) {
        var text = await resp.text();
        // Truncate long responses
        console.log("  Response (" + text.length + " chars): " + text.substring(0, 500));
        results["REST_" + i] = { path: restPaths[i], status: resp.status, body: text.substring(0, 2000) };
      }
    } catch (e) {
      console.log(restPaths[i] + " → ERROR: " + e.message);
      results["REST_" + i] = { path: restPaths[i], error: e.message };
    }
  }

  // === TEST 2: JS API — Deep debugging of activity creation ===
  console.log("\n=== TEST 2: JS API Activity Deep Debug ===");

  try {
    var app = theApplication();
    if (!app) throw new Error("theApplication() returned null");

    var viewName = app.ActiveViewName();
    console.log("Current view: " + viewName);

    // Check what applets are available in the current view
    var appletNames = [
      "Service Request List Applet",
      "Service Request Detail Applet",
      "Activity List Applet With Navigation",
      "Activity Form Applet",
      "Activity Daily Hour Applet",
      "Action Time Applet",
      "Time Applet"
    ];

    console.log("\nApplet availability:");
    for (var j = 0; j < appletNames.length; j++) {
      var a = app.FindApplet(appletNames[j]);
      console.log("  " + appletNames[j] + ": " + (a ? "FOUND" : "not found"));
      if (a) {
        try {
          var bc = a.BusComp();
          if (bc) {
            // Try to get some field values from the current record
            var fields = ["Id", "Type", "Description", "Status", "SR Number", "Owner", "Created"];
            var vals = {};
            for (var k = 0; k < fields.length; k++) {
              try { vals[fields[k]] = bc.GetFieldValue(fields[k]); } catch (e) { vals[fields[k]] = "ERR: " + e.message; }
            }
            console.log("    Current record fields:", vals);

            // Check if BC is read-only
            try {
              var isReadOnly = bc.IsReadOnly ? bc.IsReadOnly() : "method not available";
              console.log("    IsReadOnly: " + isReadOnly);
            } catch (e) {
              console.log("    IsReadOnly: ERR " + e.message);
            }

            // Try getting the BC name
            try {
              var bcName = bc.Name ? bc.Name() : "method not available";
              console.log("    BC Name: " + bcName);
            } catch (e) {
              console.log("    BC Name: ERR " + e.message);
            }

            // List all available methods on the BC object
            var methods = [];
            for (var key in bc) {
              if (typeof bc[key] === "function") methods.push(key);
            }
            console.log("    BC methods (" + methods.length + "):", methods.join(", "));
          }
        } catch (e) {
          console.log("    BC access error: " + e.message);
        }
      }
    }

    // === TEST 3: Try creating a TEST activity and see what happens ===
    console.log("\n=== TEST 3: Try NewRecord + SetFieldValue + WriteRecord ===");

    var activityApplet = app.FindApplet("Activity List Applet With Navigation");
    if (!activityApplet) activityApplet = app.FindApplet("Activity Form Applet");

    if (activityApplet) {
      var actBc = activityApplet.BusComp();

      // Get the current record's ID before NewRecord
      var currentId = "";
      try { currentId = actBc.GetFieldValue("Id"); } catch (e) {}
      console.log("Current activity record ID: " + currentId);

      // NewRecord
      console.log("Calling NewRecord...");
      actBc.InvokeMethod("NewRecord", 1);
      console.log("NewRecord done. Errors: " + app.GetErrorCount());

      // Get the new record's ID
      var newId = "";
      try { newId = actBc.GetFieldValue("Id"); } catch (e) {}
      console.log("New record ID after NewRecord: " + newId);

      // Set fields
      console.log("Setting Type field...");
      actBc.SetFieldValue("Type", "SR Note");
      var typeCheck = actBc.GetFieldValue("Type");
      console.log("Type after SetFieldValue: '" + typeCheck + "'");

      console.log("Setting Description field...");
      actBc.SetFieldValue("Description", "DIAGNOSTIC TEST - can delete");
      var descCheck = actBc.GetFieldValue("Description");
      console.log("Description after SetFieldValue: '" + descCheck + "'");

      // Check ALL field values on the new record
      var allFields = ["Id", "Type", "Description", "Status", "Owner", "Created",
        "SR Number", "Activity Type", "Comments", "Display In", "Private",
        "Target Objective", "Priority", "Planned", "Done"];
      console.log("\nAll field values on new record BEFORE WriteRecord:");
      for (var f = 0; f < allFields.length; f++) {
        try {
          var val = actBc.GetFieldValue(allFields[f]);
          if (val) console.log("  " + allFields[f] + " = '" + val + "'");
        } catch (e) {}
      }

      // Check parent reference fields
      var parentFields = ["SR Id", "Parent Id", "Parent SR Id", "Service Request Id",
        "External Reference", "Related To", "Activity SR Id"];
      console.log("\nParent reference fields:");
      for (var p = 0; p < parentFields.length; p++) {
        try {
          var pval = actBc.GetFieldValue(parentFields[p]);
          if (pval) console.log("  " + parentFields[p] + " = '" + pval + "'");
        } catch (e) {}
      }

      // Now try WriteRecord
      console.log("\nCalling WriteRecord...");
      actBc.InvokeMethod("WriteRecord");

      var errCount = app.GetErrorCount();
      console.log("WriteRecord done. Error count: " + errCount);
      if (errCount > 0) {
        for (var ei = 0; ei < errCount; ei++) {
          console.log("  Error " + ei + ": " + app.GetErrorMsg(ei));
        }
      }

      // Verify: read back fields
      var verifyType = actBc.GetFieldValue("Type");
      var verifyDesc = actBc.GetFieldValue("Description");
      var verifyId = "";
      try { verifyId = actBc.GetFieldValue("Id"); } catch (e) {}
      console.log("\nAfter WriteRecord:");
      console.log("  Id: " + verifyId);
      console.log("  Type: '" + verifyType + "'");
      console.log("  Description: '" + verifyDesc + "'");
      console.log("  (If fields are still set, record may be in memory but NOT in DB)");
    } else {
      console.log("No activity applet found — not in an SR detail view?");
    }

  } catch (e) {
    console.log("JS API error: " + e.message);
    console.log(e.stack);
  }

  // === TEST 4: Check Siebel internal SWE endpoints ===
  console.log("\n=== TEST 4: SWE Session Info ===");
  try {
    var app2 = theApplication();
    var sessionId = "";
    try { sessionId = app2.GetSessionId ? app2.GetSessionId() : "no method"; } catch (e) { sessionId = "err"; }
    console.log("Session ID: " + sessionId);

    var userName = "";
    try { userName = app2.GetUserName ? app2.GetUserName() : "no method"; } catch (e) { userName = "err"; }
    console.log("User: " + userName);

    // Check SiebelApp for REST-like capabilities
    if (typeof SiebelApp !== "undefined") {
      console.log("SiebelApp available: yes");
      try {
        var restClient = SiebelApp.S_App.GetRestClient ? SiebelApp.S_App.GetRestClient() : null;
        console.log("REST client: " + (restClient ? "available" : "not available"));
      } catch (e) {
        console.log("REST client: err " + e.message);
      }
    }
  } catch (e) {
    console.log("SWE session error: " + e.message);
  }

  console.log("\n=== DIAGNOSTIC COMPLETE ===");
  console.log("Copy all output above and share it — this tells us which approach will work.");
})();
